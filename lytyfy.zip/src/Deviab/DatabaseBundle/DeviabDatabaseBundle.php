<?php

namespace Deviab\DatabaseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DeviabDatabaseBundle extends Bundle
{
}
