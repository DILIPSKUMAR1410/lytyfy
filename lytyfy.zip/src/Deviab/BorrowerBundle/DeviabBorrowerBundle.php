<?php

namespace Deviab\BorrowerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DeviabBorrowerBundle extends Bundle
{
}
