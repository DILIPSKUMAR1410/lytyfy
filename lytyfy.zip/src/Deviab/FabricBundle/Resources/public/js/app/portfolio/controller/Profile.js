app.controller("ProfileController", function ($scope, $http) {
    $scope.amounts = "raghav";

});
