<?php

namespace Deviab\FabricBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FabricBundle extends Bundle
{
}
