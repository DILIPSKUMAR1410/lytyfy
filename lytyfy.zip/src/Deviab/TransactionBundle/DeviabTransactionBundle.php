<?php

namespace Deviab\TransactionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DeviabTransactionBundle extends Bundle
{
}
