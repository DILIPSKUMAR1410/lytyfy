<?php

namespace Deviab\RepaymentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DeviabRepaymentBundle extends Bundle
{
}
